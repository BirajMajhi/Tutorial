package com.course;
import java.sql.DriverManager;
import java.sql.Statement;
public class Connection {
    public java.sql.Connection c;
    public Statement s;

    public Connection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            c = DriverManager.getConnection("jdbc:mysql://localhost:3306/course_system", "root", "");
            s = c.createStatement();
            System.out.println("Connected");

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void main(String[] args) {
        Connection con = new Connection();
    }
}
